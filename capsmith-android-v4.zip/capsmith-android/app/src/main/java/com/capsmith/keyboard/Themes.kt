package com.capsmith.keyboard

import android.content.SharedPreferences
import org.json.JSONObject

/** Preset looks and the user's saved designs. A design is just a map of settings. */
object Themes {
    // Settings that belong to the person, not to a look, so switching looks never changes them.
    private val keep = setOf("saved", "tidx", "haptic", "vol", "tname")
    private fun c(v: Long) = v.toInt()

    val presets: LinkedHashMap<String, Map<String, Any>> = linkedMapOf(
        "Midnight" to mapOf<String, Any>(),
        "Liquid glass" to mapOf<String, Any>(
            "bg" to c(0xFFE6ECF7), "key" to c(0xFFFFFFFF), "fn" to c(0xFFD5DEEE), "legend" to c(0xFF1C2433),
            "glow" to c(0xFF7FB2FF), "glow2" to c(0xFFFF9AD5), "style" to 4, "radius" to 15, "gtint" to 26,
            "bgfx" to 1, "gmode" to 0, "popup" to 1, "sound" to 1),
        "Liquid midnight" to mapOf<String, Any>(
            "bg" to c(0xFF080B16), "key" to c(0xFF9DB4FF), "fn" to c(0xFF5A6A99), "legend" to c(0xFFFFFFFF),
            "glow" to c(0xFF3D63FF), "glow2" to c(0xFFB04CFF), "style" to 4, "radius" to 14, "gtint" to 14,
            "bgfx" to 1, "gmode" to 6, "gsize" to 10, "gpow" to 40, "popup" to 5, "sound" to 6),
        "Sunset glass" to mapOf<String, Any>(
            "bg" to c(0xFF2A0F2E), "key" to c(0xFFFFD1B3), "fn" to c(0xFFFF9E80), "legend" to c(0xFFFFFFFF),
            "glow" to c(0xFFFF6A3D), "glow2" to c(0xFFFFC23D), "style" to 4, "radius" to 18, "gtint" to 16,
            "bgfx" to 1, "gmode" to 0, "popup" to 4, "sound" to 4),
        "Ocean glass" to mapOf<String, Any>(
            "bg" to c(0xFF04222E), "key" to c(0xFFB3F5FF), "fn" to c(0xFF5FC9D9), "legend" to c(0xFFFFFFFF),
            "glow" to c(0xFF00B2FF), "glow2" to c(0xFF00FFB3), "style" to 4, "radius" to 12, "gtint" to 14,
            "bgfx" to 2, "gmode" to 2, "gsize" to 8, "gpow" to 35, "popup" to 3, "sound" to 6),
        "Candy" to mapOf<String, Any>(
            "bg" to c(0xFFFFD3E8), "key" to c(0xFFFFFFFF), "fn" to c(0xFFFF8CC6), "legend" to c(0xFF7A1F55),
            "glow" to c(0xFFFF4FA3), "glow2" to c(0xFFFFB347), "style" to 1, "radius" to 16,
            "gmode" to 6, "gsize" to 14, "popup" to 4, "sound" to 4),
        "Mint terminal" to mapOf<String, Any>(
            "bg" to c(0xFF08201C), "key" to c(0xFF10372F), "fn" to c(0xFF0B2B25), "legend" to c(0xFFD8FFF3),
            "glow" to c(0xFF3DDBB0), "style" to 3, "radius" to 6, "gmode" to 4, "gsize" to 16,
            "popup" to 3, "sound" to 2),
        "Gamer RGB" to mapOf<String, Any>(
            "bg" to c(0xFF07070C), "key" to c(0xFF171722), "fn" to c(0xFF0E0E16), "legend" to c(0xFFFFFFFF),
            "style" to 1, "radius" to 8, "gmode" to 3, "gsize" to 18, "gspeed" to 7, "gpow" to 80,
            "popup" to 2, "sound" to 2),
        "Typewriter" to mapOf<String, Any>(
            "bg" to c(0xFFC4C8CE), "key" to c(0xFFF2F2F0), "fn" to c(0xFF8F969F), "legend" to c(0xFF22252B),
            "glow" to c(0xFFFFB020), "style" to 1, "radius" to 20, "gmode" to 0, "popup" to 1, "sound" to 5),
        "Aurora glass" to mapOf<String, Any>(
            "bg" to c(0xFF0B1020), "key" to c(0xFF22304F), "fn" to c(0xFF18233B), "legend" to c(0xFFEAF2FF),
            "glow" to c(0xFF4DF0C8), "glow2" to c(0xFF8A5CFF), "style" to 2, "radius" to 14,
            "gmode" to 6, "gsize" to 16, "gspeed" to 4, "popup" to 5, "sound" to 6),
        "Neon night" to mapOf<String, Any>(
            "bg" to c(0xFF05050A), "key" to c(0xFF0A0A14), "fn" to c(0xFF0A0A14), "legend" to c(0xFFFFFFFF),
            "glow" to c(0xFFFF2BD6), "style" to 3, "radius" to 10, "gmode" to 5, "gsize" to 14,
            "popup" to 5, "sound" to 3)
    )

    private fun readSaved(sp: SharedPreferences): JSONObject =
        try { JSONObject(sp.getString("saved", "{}") ?: "{}") } catch (e: Exception) { JSONObject() }

    fun saved(sp: SharedPreferences): LinkedHashMap<String, Map<String, Any>> {
        val out = LinkedHashMap<String, Map<String, Any>>()
        try {
            val o = readSaved(sp)
            for (n in o.keys()) {
                val j = o.getJSONObject(n)
                val m = HashMap<String, Any>()
                for (k in j.keys()) m[k] = j.get(k)
                out[n] = m
            }
        } catch (e: Exception) { }
        return out
    }

    fun names(sp: SharedPreferences): List<String> = presets.keys.toList() + saved(sp).keys.toList()

    fun get(sp: SharedPreferences, n: String): Map<String, Any>? = presets[n] ?: saved(sp)[n]

    /** Every setting that makes up the current look (colors, styles, per-key colors). */
    fun snapshot(sp: SharedPreferences): Map<String, Any> {
        val m = HashMap<String, Any>()
        for ((k, v) in sp.all) if (k !in keep && (v is Int || v is Boolean)) m[k] = v as Any
        return m
    }

    /** Replace the current look. Anything the design does not mention goes back to its default. */
    fun applyTheme(sp: SharedPreferences, m: Map<String, Any>, name: String? = null) {
        val e = sp.edit()
        sp.all.keys.filter { it !in keep }.forEach { e.remove(it) }
        if (name != null) e.putString("tname", name) else e.remove("tname")
        for ((k, v) in m) when (v) {
            is Int -> e.putInt(k, v)
            is Boolean -> e.putBoolean(k, v)
        }
        e.apply()
    }

    fun save(sp: SharedPreferences, name: String) {
        val o = readSaved(sp)
        o.put(name, JSONObject(snapshot(sp)))
        sp.edit().putString("saved", o.toString()).apply()
    }

    fun delete(sp: SharedPreferences, name: String) {
        val o = readSaved(sp)
        o.remove(name)
        sp.edit().putString("saved", o.toString()).apply()
    }
}
