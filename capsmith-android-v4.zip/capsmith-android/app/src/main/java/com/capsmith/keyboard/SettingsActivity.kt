package com.capsmith.keyboard

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.text.InputFilter
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.*

class SettingsActivity : Activity() {
    private lateinit var sp: SharedPreferences
    private lateinit var box: LinearLayout
    private lateinit var tabs: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var kb: KbView
    private var tab = 0
    private val tabNames = listOf("Themes", "Keys", "Glow", "Pop-ups", "Sound", "My designs", "Setup")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun dpf(v: Float) = v * resources.displayMetrics.density
    private fun changed() = kb.reload()
    private fun putI(k: String, v: Int) {
        sp.edit().putInt(k, v).remove("tname").apply()
        changed()
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        sp = getSharedPreferences("cs", MODE_PRIVATE)
        window.statusBarColor = Ui.INK
        window.navigationBarColor = Ui.INK

        val test = field("Type on the preview keyboard")
        test.showSoftInputOnFocus = false
        test.maxLines = 3
        kb = KbView(this) { code ->
            when (code) {
                "DEL" -> {
                    val t = test.text
                    if (t.isNotEmpty()) t.delete(t.length - 1, t.length)
                }
                "ENTER" -> test.append("\n")
                else -> test.append(code)
            }
        }

        val header = LinearLayout(this)
        header.orientation = LinearLayout.VERTICAL
        header.setPadding(dp(20), dp(18), dp(20), dp(6))
        val title = TextView(this)
        title.text = "Capsmith"
        title.textSize = 32f
        title.setTextColor(Color.WHITE)
        title.typeface = Typeface.create("sans-serif-black", Typeface.NORMAL)
        title.letterSpacing = -0.02f
        header.addView(title)
        header.addView(text("Design a keyboard that's yours.", 14f, Ui.MUTED))
        header.addView(test, lp(-1, -2).apply { topMargin = dp(14) })

        tabs = LinearLayout(this)
        tabs.setPadding(dp(14), 0, dp(14), 0)
        val tabScroll = HorizontalScrollView(this)
        tabScroll.isHorizontalScrollBarEnabled = false
        tabScroll.addView(tabs)

        box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), 0, dp(16), dp(24))
        scroll = ScrollView(this)
        scroll.isVerticalScrollBarEnabled = false
        scroll.addView(box)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.fitsSystemWindows = true
        root.background = BlobBackground()
        root.addView(header)
        root.addView(tabScroll)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(kb, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)

        tab = if (enabled()) 0 else tabNames.size - 1
        ui()
    }

    override fun onResume() {
        super.onResume()
        if (::box.isInitialized && tab == tabNames.size - 1) ui()
    }

    private fun enabled(): Boolean = try {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.enabledInputMethodList.any { it.packageName == packageName }
    } catch (e: Exception) {
        true
    }

    private fun ui() {
        tabs.removeAllViews()
        for ((i, n) in tabNames.withIndex()) tabs.addView(chip(n, i == tab) {
            tab = i
            ui()
            scroll.scrollTo(0, 0)
        })
        box.removeAllViews()
        when (tab) {
            0 -> themesTab()
            1 -> keysTab()
            2 -> glowTab()
            3 -> popTab()
            4 -> soundTab()
            5 -> designsTab()
            else -> setupTab()
        }
    }

    // ---------------- tabs ----------------

    private fun themesTab() {
        val s = section("Themes", "Tap a look to try it. The ◐ key on the keyboard cycles through these too.")
        val all = LinkedHashMap<String, Map<String, Any>>()
        all.putAll(Themes.presets)
        all.putAll(Themes.saved(sp))
        val cur = sp.getString("tname", null)
        var row = LinearLayout(this)
        var n = 0
        for ((name, m) in all) {
            if (n % 2 == 0) {
                row = LinearLayout(this)
                s.addView(row, lp(-1, -2))
            }
            val cell = LinearLayout(this)
            cell.orientation = LinearLayout.VERTICAL
            cell.setPadding(dp(6), dp(6), dp(6), dp(8))
            cell.background = if (name == cur) card(18, 0x22FFFFFF, Ui.ACC, 2) else card(18, 0x0DFFFFFF, 0x1AFFFFFF)
            cell.addView(ThemeSwatch(this, m), lp(-1, dp(86)))
            val t = text(name, 13f, Color.WHITE)
            t.gravity = Gravity.CENTER
            t.setPadding(0, dp(6), 0, 0)
            cell.addView(t)
            cell.setOnClickListener {
                Themes.applyTheme(sp, m, name)
                changed()
                ui()
            }
            row.addView(cell, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(4), dp(10), dp(4), 0) })
            n++
        }
        if (n % 2 == 1) row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f).apply { setMargins(dp(4), 0, dp(4), 0) })
    }

    private fun keysTab() {
        val s1 = section("Key style")
        choices(s1, null, "style", listOf("Flat", "3D keycap", "Glass", "Neon outline", "Liquid glass"), 1)
        slider(s1, "Liquid glass tint", "gtint", 0, 70, 30) { "$it%" }

        val s2 = section("Background", "Color blobs and Gradient use your two glow colors, and show through liquid glass keys.")
        choices(s2, null, "bgfx", listOf("Solid", "Color blobs", "Gradient"), 0)
        colorRow(s2, "Background color", "bg", D.bg)

        val s3 = section("Shape and size")
        slider(s3, "Corner roundness", "radius", 0, 24, 10)
        slider(s3, "Key height", "kh", 36, 64, 50)
        slider(s3, "Space between keys", "gap", 2, 14, 6)

        val s4 = section("Colors")
        colorRow(s4, "Keys", "key", D.key)
        colorRow(s4, "Function keys", "fn", D.fn)
        colorRow(s4, "Letters", "legend", D.legend)

        val s5 = section("Single-key colors", "Give one letter or number its own color.")
        val one = field("Type one letter or number")
        one.filters = arrayOf(InputFilter.LengthFilter(1))
        s5.addView(one, lp(-1, -2).apply { topMargin = dp(10) })
        primary(s5, "Pick a color for that key") {
            val ch = one.text.toString().lowercase()
            if (ch.isEmpty()) {
                Toast.makeText(this, "Type a letter or number first", Toast.LENGTH_SHORT).show()
            } else {
                pick(sp.getInt("kc_$ch", sp.getInt("key", D.key))) { putI("kc_$ch", it) }
            }
        }
        secondary(s5, "Clear all single-key colors") {
            val e = sp.edit()
            sp.all.keys.filter { it.startsWith("kc_") }.forEach { e.remove(it) }
            e.apply()
            changed()
        }
    }

    private fun glowTab() {
        val s = section("Underglow", "Light that spills out around the keys, like a gaming keyboard.")
        choices(
            s, null, "gmode",
            listOf("Off", "Solid", "Breathing", "Rainbow wave", "Reactive", "Twinkle", "Aurora"), 3
        )
        colorRow(s, "Glow color", "glow", D.glow)
        colorRow(s, "Second color", "glow2", D.glow2)
        slider(s, "Glow size", "gsize", 0, 30, 12)
        slider(s, "Brightness", "gpow", 0, 100, 60) { "$it%" }
        slider(s, "Animation speed", "gspeed", 1, 10, 5)
    }

    private fun popTab() {
        val s = section("Key press pop-up", "What appears when you tap a key. With Liquid glass keys, the bubble is glass too.")
        choices(s, null, "popup", listOf("None", "Bubble", "Zoom", "Ripple ring", "Floating letter", "Sparks"), 1)
    }

    private fun soundTab() {
        val s = section("Key sound")
        choices(s, null, "sound", listOf("Off", "Soft", "Clicky", "Thock", "Pop", "Typewriter", "Marimba"), 2)
        slider(s, "Volume", "vol", 0, 100, 60) { "$it%" }
        val sw = Switch(this)
        sw.text = "Vibrate on key press"
        sw.textSize = 15f
        sw.setTextColor(Color.WHITE)
        val st = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        sw.thumbTintList = ColorStateList(st, intArrayOf(Color.WHITE, 0xFFB0B8CC.toInt()))
        sw.trackTintList = ColorStateList(st, intArrayOf(Ui.ACC, 0x55FFFFFF))
        sw.isChecked = sp.getBoolean("haptic", true)
        sw.setOnCheckedChangeListener { _, c ->
            sp.edit().putBoolean("haptic", c).apply()
            changed()
        }
        s.addView(sw, lp(-1, -2).apply { topMargin = dp(14) })
    }

    private fun designsTab() {
        val s = section("Save this look", "Saved designs show up in Themes and on the ◐ key.")
        val nm = field("Name this design")
        nm.setSingleLine()
        s.addView(nm, lp(-1, -2).apply { topMargin = dp(10) })
        primary(s, "Save design") {
            var n = nm.text.toString().trim().ifEmpty { "My design" }
            if (Themes.presets.containsKey(n)) n += " 2"
            Themes.save(sp, n)
            sp.edit().putString("tname", n).apply()
            Toast.makeText(this, "Saved $n", Toast.LENGTH_SHORT).show()
            ui()
        }

        val saved = Themes.saved(sp)
        if (saved.isNotEmpty()) {
            val l = section("My designs")
            for ((n, m) in saved) {
                val row = LinearLayout(this)
                row.gravity = Gravity.CENTER_VERTICAL
                row.setPadding(0, dp(8), 0, 0)
                row.addView(ThemeSwatch(this, m), lp(dp(72), dp(46)))
                val t = text(n, 15f, Color.WHITE)
                t.setPadding(dp(12), 0, dp(8), 0)
                row.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
                row.addView(chip("Use", false) {
                    Themes.applyTheme(sp, m, n)
                    changed()
                    ui()
                })
                row.addView(chip("Delete", false) {
                    Themes.delete(sp, n)
                    ui()
                })
                l.addView(row)
            }
        }

        val r = section("Reset")
        secondary(r, "Go back to the default look") {
            Themes.applyTheme(sp, emptyMap(), "Midnight")
            changed()
            ui()
        }
    }

    private fun setupTab() {
        val on = enabled()
        val s = section(
            "Set up Capsmith",
            if (on) "Capsmith is turned on. Switch to it whenever you're typing." else "Two quick steps and Capsmith is your keyboard."
        )
        if (!on) {
            s.addView(text("1. Turn Capsmith on in your phone's keyboard settings and accept the warning.", 14f, Color.WHITE)
                .apply { setPadding(0, dp(12), 0, 0) })
            primary(s, "Open keyboard settings") { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        }
        s.addView(text("${if (on) "" else "2. "}Pick Capsmith as the keyboard you're using.", 14f, Color.WHITE)
            .apply { setPadding(0, dp(14), 0, 0) })
        primary(s, "Switch to Capsmith") {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        }
    }

    // ---------------- building blocks ----------------

    private fun lp(w: Int, h: Int) = LinearLayout.LayoutParams(w, h)

    private fun text(t: String, size: Float, color: Int): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = size
        v.setTextColor(color)
        return v
    }

    private fun card(radius: Int, fill: Int = Ui.CARD, stroke: Int = Ui.STROKE, strokeW: Int = 1): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(fill)
        g.cornerRadius = dpf(radius.toFloat())
        g.setStroke(dp(strokeW), stroke)
        return g
    }

    private fun accent(radius: Int): GradientDrawable {
        val g = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Ui.ACC, Ui.ACC2))
        g.cornerRadius = dpf(radius.toFloat())
        return g
    }

    private fun field(hint: String): EditText {
        val e = EditText(this)
        e.hint = hint
        e.textSize = 16f
        e.setTextColor(Color.WHITE)
        e.setHintTextColor(Ui.MUTED)
        e.background = card(16, 0x24FFFFFF, 0x33FFFFFF)
        e.setPadding(dp(16), dp(12), dp(16), dp(12))
        return e
    }

    private fun section(title: String, hint: String? = null): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = card(24)
        c.setPadding(dp(18), dp(16), dp(18), dp(18))
        val t = text(title, 18f, Color.WHITE)
        t.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        c.addView(t)
        if (hint != null) c.addView(text(hint, 13f, Ui.MUTED).apply { setPadding(0, dp(3), 0, 0) })
        box.addView(c, lp(-1, -2).apply { topMargin = dp(12) })
        return c
    }

    private fun chip(label: String, on: Boolean, f: () -> Unit): TextView {
        val t = text(label, 14f, if (on) Ui.INK else Color.WHITE)
        if (on) t.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        t.setPadding(dp(16), dp(9), dp(16), dp(9))
        t.background = if (on) accent(999) else card(999, 0x1FFFFFFF, 0x33FFFFFF)
        t.setOnClickListener { f() }
        t.layoutParams = LinearLayout.LayoutParams(-2, -2).apply { setMargins(dp(4), dp(6), dp(4), dp(6)) }
        return t
    }

    private fun choices(parent: LinearLayout, title: String?, key: String, opts: List<String>, def: Int) {
        if (title != null) parent.addView(text(title, 13f, Ui.MUTED).apply { setPadding(0, dp(12), 0, 0) })
        val f = Flow(this)
        f.setPadding(0, dp(8), 0, 0)
        val cur = sp.getInt(key, def)
        for ((i, o) in opts.withIndex()) f.addView(chip(o, i == cur) {
            putI(key, i)
            ui()
        })
        parent.addView(f, lp(-1, -2))
    }

    private fun slider(
        parent: LinearLayout, title: String, key: String, lo: Int, hi: Int, def: Int,
        fmt: (Int) -> String = { it.toString() }
    ) {
        val row = LinearLayout(this)
        row.setPadding(0, dp(14), 0, 0)
        row.addView(text(title, 15f, Color.WHITE), LinearLayout.LayoutParams(0, -2, 1f))
        val v = text(fmt(sp.getInt(key, def)), 15f, Ui.ACC)
        row.addView(v)
        parent.addView(row)
        val sb = SeekBar(this)
        sb.max = hi - lo
        sb.progress = sp.getInt(key, def) - lo
        sb.progressTintList = ColorStateList.valueOf(Ui.ACC)
        sb.thumbTintList = ColorStateList.valueOf(Color.WHITE)
        sb.progressBackgroundTintList = ColorStateList.valueOf(0x55FFFFFF)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                if (u) {
                    v.text = fmt(p + lo)
                    putI(key, p + lo)
                }
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        parent.addView(sb, lp(-1, -2).apply { topMargin = dp(4) })
    }

    private fun dot(color: Int, size: Int): View {
        val v = View(this)
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(color)
        g.setStroke(dp(2), 0xCCFFFFFF.toInt())
        v.background = g
        v.layoutParams = LinearLayout.LayoutParams(dp(size), dp(size))
        return v
    }

    private fun colorRow(parent: LinearLayout, title: String, key: String, def: Int) {
        val row = LinearLayout(this)
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(0, dp(12), 0, dp(4))
        row.addView(text(title, 15f, Color.WHITE), LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(dot(sp.getInt(key, def), 30))
        row.setOnClickListener {
            pick(sp.getInt(key, def)) {
                putI(key, it)
                ui()
            }
        }
        parent.addView(row)
    }

    private fun primary(parent: LinearLayout, label: String, f: () -> Unit) {
        val b = text(label, 15f, Ui.INK)
        b.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        b.gravity = Gravity.CENTER
        b.setPadding(dp(16), dp(13), dp(16), dp(13))
        b.background = accent(999)
        b.setOnClickListener { f() }
        parent.addView(b, lp(-1, -2).apply { topMargin = dp(12) })
    }

    private fun secondary(parent: LinearLayout, label: String, f: () -> Unit) {
        val b = text(label, 15f, Color.WHITE)
        b.gravity = Gravity.CENTER
        b.setPadding(dp(16), dp(13), dp(16), dp(13))
        b.background = card(999, 0x1FFFFFFF, 0x40FFFFFF)
        b.setOnClickListener { f() }
        parent.addView(b, lp(-1, -2).apply { topMargin = dp(10) })
    }

    private fun pick(start: Int, done: (Int) -> Unit) {
        val hsv = FloatArray(3)
        Color.colorToHSV(start, hsv)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(22), dp(16), dp(22), dp(4))
        val prev = View(this)
        col.addView(prev, lp(-1, dp(64)))
        val hex = text("", 14f, Ui.MUTED)
        hex.gravity = Gravity.CENTER
        hex.setPadding(0, dp(6), 0, dp(4))
        col.addView(hex)
        val bars = ArrayList<SeekBar>()
        fun cur() = Color.HSVToColor(hsv)
        fun upd() {
            prev.background = card(16, cur(), 0x55FFFFFF)
            hex.text = "#%06X".format(0xFFFFFF and cur())
        }
        val quick = Flow(this)
        val swatches = intArrayOf(
            0xFFFFFFFF.toInt(), 0xFF101420.toInt(), 0xFFFF4F6D.toInt(), 0xFFFF9F45.toInt(),
            0xFFFFD84D.toInt(), 0xFF3DDB8B.toInt(), 0xFF2EC5FF.toInt(), 0xFF5B7CFF.toInt(),
            0xFFA45BFF.toInt(), 0xFFFF5CC8.toInt(), 0xFFB3F5FF.toInt(), 0xFFFFD1B3.toInt()
        )
        for (q in swatches) {
            val d = dot(q, 32)
            (d.layoutParams as LinearLayout.LayoutParams).setMargins(dp(5), dp(6), dp(5), dp(6))
            d.setOnClickListener {
                Color.colorToHSV(q, hsv)
                val h0 = hsv[0]
                val s0 = hsv[1]
                val v0 = hsv[2]
                bars[0].progress = h0.toInt()
                bars[1].progress = (s0 * 100).toInt()
                bars[2].progress = (v0 * 100).toInt()
                hsv[0] = h0; hsv[1] = s0; hsv[2] = v0
                upd()
            }
            quick.addView(d)
        }
        col.addView(quick, lp(-1, -2))
        fun bar(name: String, max: Int, v: Int, set: (Int) -> Unit) {
            col.addView(text(name, 13f, Ui.MUTED).apply { setPadding(0, dp(8), 0, 0) })
            val sb = SeekBar(this)
            sb.max = max
            sb.progress = v
            sb.progressTintList = ColorStateList.valueOf(Ui.ACC)
            sb.thumbTintList = ColorStateList.valueOf(Color.WHITE)
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    if (u) {
                        set(p)
                        upd()
                    }
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
            bars.add(sb)
            col.addView(sb)
        }
        bar("Hue", 360, hsv[0].toInt()) { hsv[0] = it.toFloat() }
        bar("Saturation", 100, (hsv[1] * 100).toInt()) { hsv[1] = it / 100f }
        bar("Brightness", 100, (hsv[2] * 100).toInt()) { hsv[2] = it / 100f }
        upd()
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Pick a color")
            .setView(col)
            .setPositiveButton("Use color") { _, _ -> done(cur()) }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
