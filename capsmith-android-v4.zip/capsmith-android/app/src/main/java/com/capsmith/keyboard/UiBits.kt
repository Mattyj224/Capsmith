package com.capsmith.keyboard

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.util.AttributeSet
import android.view.View
import android.view.ViewGroup
import kotlin.math.max
import kotlin.math.min

/** Colors for the settings app itself. */
object Ui {
    val ACC = 0xFF8FA8FF.toInt()
    val ACC2 = 0xFFC28BFF.toInt()
    val INK = 0xFF0B0F1E.toInt()
    val MUTED = 0xFFA9B3CC.toInt()
    val CARD = 0x1AFFFFFF
    val STROKE = 0x2EFFFFFF
}

/** Deep navy background with soft colored light blobs, so the glass cards have something to sit on. */
class BlobBackground : Drawable() {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun draw(c: Canvas) {
        val w = bounds.width().toFloat()
        val h = bounds.height().toFloat()
        if (w <= 0f || h <= 0f) return
        p.shader = LinearGradient(0f, 0f, 0f, h, 0xFF0B0F1E.toInt(), 0xFF151B36.toInt(), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, p)
        blob(c, w * 0.08f, h * 0.06f, w * 0.75f, 0x667C5CFF)
        blob(c, w * 0.98f, h * 0.28f, w * 0.65f, 0x5533B6FF)
        blob(c, w * 0.25f, h * 0.70f, w * 0.75f, 0x40FF5CC8)
        p.shader = null
    }

    private fun blob(c: Canvas, x: Float, y: Float, r: Float, col: Int) {
        p.shader = RadialGradient(x, y, r, col, col and 0x00FFFFFF, Shader.TileMode.CLAMP)
        c.drawCircle(x, y, r, p)
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.OPAQUE
}

/** A tiny picture of a keyboard theme, used in the theme gallery. */
class ThemeSwatch(ctx: Context, private val m: Map<String, Any>) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val d = resources.displayMetrics.density
    private val clip = Path()

    private fun i(k: String, def: Int): Int = (m[k] as? Int) ?: def

    private fun dark(c: Int, f: Float): Int =
        Color.rgb((Color.red(c) * f).toInt(), (Color.green(c) * f).toInt(), (Color.blue(c) * f).toInt())

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val bg = i("bg", D.bg)
        val key = i("key", D.key)
        val fn = i("fn", D.fn)
        val lg = i("legend", D.legend)
        val g1 = i("glow", D.glow)
        val g2 = i("glow2", D.glow2)
        val style = i("style", 1)
        val gmode = i("gmode", 3)
        val bgfx = i("bgfx", 0)
        val cr = 14 * d
        clip.reset()
        clip.addRoundRect(RectF(0f, 0f, w, h), cr, cr, Path.Direction.CW)
        c.save()
        c.clipPath(clip)
        c.drawColor(bg)
        if (bgfx != 0) {
            for ((x, y, col) in listOf(Triple(0.15f, 0.3f, g1), Triple(0.9f, 0.2f, g2), Triple(0.5f, 1f, g1))) {
                p.shader = RadialGradient(
                    x * w, y * h, w * 0.55f, (col and 0x00FFFFFF) or (0xC8 shl 24), col and 0x00FFFFFF,
                    Shader.TileMode.CLAMP
                )
                c.drawCircle(x * w, y * h, w * 0.55f, p)
            }
            p.shader = null
        }
        val cols = 5
        val rows = 3
        val gap = 5 * d
        val pad = 9 * d
        val kw = (w - 2 * pad - (cols - 1) * gap) / cols
        val kh = (h - 2 * pad - (rows - 1) * gap) / rows
        val kr = min(i("radius", 10) * d * 0.5f, kh / 2)
        for (row in 0 until rows) for (col in 0 until cols) {
            val l = pad + col * (kw + gap)
            val t = pad + row * (kh + gap)
            val r = RectF(l, t, l + kw, t + kh)
            val base = if (row == 2 && (col == 0 || col == 4)) fn else key
            if (gmode > 0) {
                p.style = Paint.Style.FILL
                p.color = if (gmode == 3) Color.HSVToColor(floatArrayOf(col * 55f + row * 30f, 0.8f, 1f)) else g1
                p.alpha = 80
                val e = 3 * d
                c.drawRoundRect(r.left - e, r.top - e + d, r.right + e, r.bottom + e + d, kr + e, kr + e, p)
            }
            p.style = Paint.Style.FILL
            when (style) {
                2, 4 -> {
                    p.color = base; p.alpha = if (style == 4) 75 else 95
                    c.drawRoundRect(r, kr, kr, p)
                    p.color = Color.WHITE; p.alpha = 70
                    c.drawRoundRect(r.left, r.top, r.right, r.centerY(), kr, kr, p)
                    p.style = Paint.Style.STROKE; p.strokeWidth = d; p.alpha = 190
                    c.drawRoundRect(r, kr, kr, p)
                }
                3 -> {
                    p.color = Color.WHITE; p.alpha = 18
                    c.drawRoundRect(r, kr, kr, p)
                    p.style = Paint.Style.STROKE; p.strokeWidth = 1.5f * d; p.color = g1
                    c.drawRoundRect(r, kr, kr, p)
                }
                1 -> {
                    p.color = dark(base, 0.5f)
                    c.drawRoundRect(r.left, r.top + 2 * d, r.right, r.bottom + 2 * d, kr, kr, p)
                    p.color = base
                    c.drawRoundRect(r, kr, kr, p)
                }
                else -> {
                    p.color = base
                    c.drawRoundRect(r, kr, kr, p)
                }
            }
        }
        tp.color = lg
        tp.textSize = kh * 0.55f
        val mr = pad + 2 * (kw + gap) + kw / 2
        c.drawText("Aa", mr, pad + kh * 0.5f + tp.textSize * 0.35f, tp)
        c.restore()
    }
}

/** Lays children out left to right and wraps to a new line when a row is full (used for chips). */
class Flow(ctx: Context) : ViewGroup(ctx) {
    override fun onMeasure(ws: Int, hs: Int) {
        val maxW = MeasureSpec.getSize(ws) - paddingLeft - paddingRight
        var x = 0
        var y = 0
        var rowH = 0
        for (i in 0 until childCount) {
            val ch = getChildAt(i)
            measureChildWithMargins(ch, ws, 0, MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED), 0)
            val lp = ch.layoutParams as ViewGroup.MarginLayoutParams
            val cw = ch.measuredWidth + lp.leftMargin + lp.rightMargin
            val chh = ch.measuredHeight + lp.topMargin + lp.bottomMargin
            if (x > 0 && x + cw > maxW) {
                x = 0; y += rowH; rowH = 0
            }
            x += cw
            rowH = max(rowH, chh)
        }
        setMeasuredDimension(MeasureSpec.getSize(ws), y + rowH + paddingTop + paddingBottom)
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val maxW = r - l - paddingLeft - paddingRight
        var x = 0
        var y = 0
        var rowH = 0
        for (i in 0 until childCount) {
            val ch = getChildAt(i)
            val lp = ch.layoutParams as ViewGroup.MarginLayoutParams
            val cw = ch.measuredWidth + lp.leftMargin + lp.rightMargin
            val chh = ch.measuredHeight + lp.topMargin + lp.bottomMargin
            if (x > 0 && x + cw > maxW) {
                x = 0; y += rowH; rowH = 0
            }
            val cl = paddingLeft + x + lp.leftMargin
            val ct = paddingTop + y + lp.topMargin
            ch.layout(cl, ct, cl + ch.measuredWidth, ct + ch.measuredHeight)
            x += cw
            rowH = max(rowH, chh)
        }
    }

    override fun generateLayoutParams(attrs: AttributeSet?): ViewGroup.LayoutParams =
        ViewGroup.MarginLayoutParams(context, attrs)

    override fun generateDefaultLayoutParams(): ViewGroup.LayoutParams =
        ViewGroup.MarginLayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)

    override fun generateLayoutParams(p: ViewGroup.LayoutParams?): ViewGroup.LayoutParams =
        ViewGroup.MarginLayoutParams(p)

    override fun checkLayoutParams(p: ViewGroup.LayoutParams?): Boolean = p is ViewGroup.MarginLayoutParams
}
