package com.capsmith.keyboard

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.text.InputFilter
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.*

class SettingsActivity : Activity() {
    private lateinit var sp: SharedPreferences
    private lateinit var box: LinearLayout
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        sp = getSharedPreferences("cs", MODE_PRIVATE)
        box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(40))
        }
        setContentView(ScrollView(this).apply { fitsSystemWindows = true; addView(box) })

        head("Capsmith")
        btn("1. Turn on the keyboard") { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        btn("2. Switch to Capsmith") {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        }
        box.addView(EditText(this).apply { hint = "Tap here to try your keyboard" })

        head("Key style")
        choice("Look", "style", listOf("Flat", "3D keycap", "Glass"), 1)
        slider("Corner roundness", "radius", 20, 10)
        color("Key color", "key", D.key)
        color("Function key color", "fn", D.fn)
        color("Legend (letter) color", "legend", D.legend)
        color("Keyboard background", "bg", D.bg)

        head("Single-key colors")
        val one = EditText(this).apply {
            hint = "Type one letter or number"
            filters = arrayOf(InputFilter.LengthFilter(1))
        }
        box.addView(one)
        btn("Pick a color for that key") {
            val ch = one.text.toString().lowercase()
            if (ch.isNotEmpty()) pick(sp.getInt("kc_$ch", sp.getInt("key", D.key))) {
                sp.edit().putInt("kc_$ch", it).apply()
            }
        }
        btn("Clear all single-key colors") {
            val e = sp.edit()
            sp.all.keys.filter { it.startsWith("kc_") }.forEach { e.remove(it) }
            e.apply()
        }

        head("Underglow")
        choice("Effect", "gmode", listOf("Off", "Solid", "Breathing", "Rainbow wave", "Reactive (lights where you type)"), 3)
        color("Glow color (Solid, Breathing, Reactive)", "glow", D.glow)
        slider("Glow size", "gsize", 24, 12)
        slider("Animation speed", "gspeed", 10, 5)

        head("Key press pop-up")
        choice("Pop-up", "popup", listOf("None", "Bubble", "Zoom", "Ripple ring"), 1)

        head("Sound and feel")
        choice("Key sound", "sound", listOf("Off", "Soft", "Clicky", "Thock", "Pop"), 2)
        slider("Volume", "vol", 100, 60)
        box.addView(Switch(this).apply {
            text = "Vibrate on key press"
            isChecked = sp.getBoolean("haptic", true)
            setOnCheckedChangeListener { _, c -> sp.edit().putBoolean("haptic", c).apply() }
        })

        head("Reset")
        btn("Reset everything") { sp.edit().clear().apply(); recreate() }
    }

    private fun head(t: String) = box.addView(TextView(this).apply {
        text = t; textSize = 18f; setTypeface(null, Typeface.BOLD); setPadding(0, dp(24), 0, dp(6))
    })

    private fun btn(t: String, f: () -> Unit) = box.addView(Button(this).apply {
        text = t; isAllCaps = false; setOnClickListener { f() }
    })

    private fun label(t: String) = box.addView(TextView(this).apply { text = t; setPadding(0, dp(10), 0, 0) })

    private fun color(title: String, key: String, def: Int) {
        val b = Button(this).apply { isAllCaps = false; text = title }
        fun paint() {
            val c = sp.getInt(key, def)
            b.background = GradientDrawable().apply { setColor(c); cornerRadius = dp(10).toFloat(); setStroke(dp(1), Color.GRAY) }
            b.setTextColor(if (Color.luminance(c) > 0.5f) Color.BLACK else Color.WHITE)
        }
        paint()
        b.setOnClickListener { pick(sp.getInt(key, def)) { sp.edit().putInt(key, it).apply(); paint() } }
        box.addView(b)
    }

    private fun pick(start: Int, done: (Int) -> Unit) {
        val hsv = FloatArray(3); Color.colorToHSV(start, hsv)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(10), dp(20), 0) }
        val sw = View(this)
        col.addView(sw, LinearLayout.LayoutParams(-1, dp(48)))
        fun cur() = Color.HSVToColor(hsv)
        fun upd() = sw.setBackgroundColor(cur())
        fun bar(name: String, max: Int, v: Int, set: (Int) -> Unit) {
            col.addView(TextView(this).apply { text = name })
            col.addView(SeekBar(this).apply {
                this.max = max; progress = v
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { set(p); upd() }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
            })
        }
        bar("Hue", 360, hsv[0].toInt()) { hsv[0] = it.toFloat() }
        bar("Saturation", 100, (hsv[1] * 100).toInt()) { hsv[1] = it / 100f }
        bar("Brightness", 100, (hsv[2] * 100).toInt()) { hsv[2] = it / 100f }
        upd()
        AlertDialog.Builder(this).setView(col)
            .setPositiveButton("Use color") { _, _ -> done(cur()) }
            .setNegativeButton("Cancel", null).show()
    }

    private fun choice(title: String, key: String, opts: List<String>, def: Int) {
        label(title)
        box.addView(Spinner(this).apply {
            adapter = ArrayAdapter(this@SettingsActivity, android.R.layout.simple_spinner_dropdown_item, opts)
            setSelection(sp.getInt(key, def))
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                    sp.edit().putInt(key, pos).apply()
                }
                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
        })
    }

    private fun slider(title: String, key: String, max: Int, def: Int) {
        label(title)
        box.addView(SeekBar(this).apply {
            this.max = max; progress = sp.getInt(key, def)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { sp.edit().putInt(key, p).apply() }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
    }
}
