package com.capsmith.keyboard

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.media.*
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.SparseIntArray
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import kotlin.math.*
import kotlin.random.Random

/** Default colors. Shared by the keyboard and the settings screen. */
object D {
    val bg = 0xFF10131C.toInt()
    val key = 0xFF2A3042.toInt()
    val fn = 0xFF1B2030.toInt()
    val legend = 0xFFE6EBFF.toInt()
    val glow = 0xFF6F8BFF.toInt()
}

class KbView(ctx: Context, private val send: (String) -> Unit) : View(ctx) {
    private class Key(val code: String, val label: String, val fn: Boolean, val w: Float, val row: Int) {
        val r = RectF()
    }

    private val sp = ctx.getSharedPreferences("cs", Context.MODE_PRIVATE)
    private val dm = resources.displayMetrics.density
    private fun dp(v: Float) = v * dm
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val hd = Handler(Looper.getMainLooper())
    private var keys: List<Key> = emptyList()
    private var layer = 0
    private var shift = false
    private val down = BooleanArray(64)
    private val last = LongArray(64)
    private val ptr = SparseIntArray()
    private var perKey: Map<String, Int> = emptyMap()

    private var cBg = D.bg; private var cKey = D.key; private var cFn = D.fn
    private var cLg = D.legend; private var cGlow = D.glow
    private var style = 1; private var gMode = 3; private var gSize = 0f; private var speed = 1f
    private var popup = 1; private var pack = 2; private var vol = 0.6f; private var rad = 0f
    private var haptic = true

    private val tracks = arrayOfNulls<AudioTrack>(5)
    private val rep = object : Runnable {
        override fun run() { send("DEL"); play(true); hd.postDelayed(this, 55) }
    }

    init { reload(); build() }

    fun reload() {
        cBg = sp.getInt("bg", D.bg); cKey = sp.getInt("key", D.key); cFn = sp.getInt("fn", D.fn)
        cLg = sp.getInt("legend", D.legend); cGlow = sp.getInt("glow", D.glow)
        style = sp.getInt("style", 1); gMode = sp.getInt("gmode", 3)
        gSize = dp(sp.getInt("gsize", 12).toFloat()); speed = sp.getInt("gspeed", 5) / 5f
        popup = sp.getInt("popup", 1); pack = sp.getInt("sound", 2)
        vol = sp.getInt("vol", 60) / 100f; rad = dp(sp.getInt("radius", 10).toFloat())
        haptic = sp.getBoolean("haptic", true)
        perKey = sp.all.filter { it.key.startsWith("kc_") && it.value is Int }.mapValues { it.value as Int }
        invalidate()
    }

    // ---------- layout ----------
    private fun top() = dp(72f)

    override fun onMeasure(w: Int, hs: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), (top() + 4 * dp(50f) + 3 * dp(8f) + dp(16f)).toInt())
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) = place(w.toFloat())

    private fun build() {
        val r0 = if (layer == 0) "qwertyuiop" else "1234567890"
        val r1 = if (layer == 0) "asdfghjkl" else "-/:;()\$&@\""
        val l = ArrayList<Key>()
        r0.forEach { l.add(Key(it.toString(), it.toString(), false, 1f, 0)) }
        r1.forEach { l.add(Key(it.toString(), it.toString(), false, 1f, 1)) }
        if (layer == 0) l.add(Key("SHIFT", "⇧", true, 1.5f, 2))
        (if (layer == 0) "zxcvbnm" else ".,?!'").forEach { l.add(Key(it.toString(), it.toString(), false, 1f, 2)) }
        l.add(Key("DEL", "⌫", true, 1.5f, 2))
        val sw = if (layer == 0) "123" else "ABC"
        l.add(Key(sw, sw, true, 1.6f, 3))
        l.add(Key("SPACE", "", false, 5f, 3))
        l.add(Key("ENTER", "⏎", true, 1.6f, 3))
        keys = l; down.fill(false); last.fill(0L); ptr.clear()
        place(width.toFloat()); invalidate()
    }

    private fun place(width: Float) {
        if (width <= 0f) return
        val pad = dp(6f); val gx = dp(6f); val gy = dp(8f); val kh = dp(50f)
        val avail = width - 2 * pad
        val unit0 = (avail - 9 * gx) / 10f
        for (row in 0..3) {
            val rk = keys.filter { it.row == row }
            val n = rk.size
            val sum = rk.sumOf { it.w.toDouble() }.toFloat()
            val unit = if (row == 3) (avail - (n - 1) * gx) / sum else unit0
            var x = (width - (sum * unit + (n - 1) * gx)) / 2f
            val y = top() + row * (kh + gy)
            for (k in rk) { val kw = k.w * unit; k.r.set(x, y, x + kw, y + kh); x += kw + gx }
        }
    }

    // ---------- drawing ----------
    private fun shade(c: Int, f: Float): Int {
        val h = FloatArray(3); Color.colorToHSV(c, h)
        h[2] = (h[2] * f + (if (f > 1f) (f - 1f) * 0.2f else 0f)).coerceIn(0f, 1f)
        return Color.HSVToColor(Color.alpha(c), h)
    }

    private fun label(k: Key) =
        if (shift && layer == 0 && k.code.length == 1 && k.code[0].isLetter()) k.label.uppercase() else k.label

    override fun onDraw(c: Canvas) {
        val now = SystemClock.uptimeMillis(); val t = now / 1000f
        var anim = false
        c.drawColor(cBg)

        // underglow
        if (gMode > 0 && gSize > 0f) for ((i, k) in keys.withIndex()) {
            var a = 1f; var col = cGlow
            when (gMode) {
                2 -> { a = 0.55f + 0.45f * sin(t * 2.2f * speed); anim = true }
                3 -> {
                    val hue = (t * 45f * speed + k.r.centerX() / width * 360f + k.row * 25f) % 360f
                    col = Color.HSVToColor(floatArrayOf(hue, 0.85f, 1f)); anim = true
                }
                4 -> { a = max(0.12f, 1f - (now - last[i]) / 1200f); if (a > 0.12f) anim = true }
            }
            glow(c, k.r, col, a)
        }

        for ((i, k) in keys.withIndex()) drawKey(c, k, down[i], false)

        // press pop-ups (drawn last so neighbours never cover them)
        for ((i, k) in keys.withIndex()) {
            if (down[i] && k.code.length == 1) when (popup) {
                1 -> bubble(c, k)
                2 -> { c.save(); c.scale(1.3f, 1.3f, k.r.centerX(), k.r.bottom); drawKey(c, k, false, true); c.restore() }
            }
            if (popup == 3 && last[i] > 0L) {
                val age = (now - last[i]) / 450f
                if (age in 0f..1f) {
                    p.shader = null; p.style = Paint.Style.STROKE; p.strokeWidth = dp(3f)
                    p.color = cGlow; p.alpha = (255 * (1f - age)).toInt()
                    c.drawCircle(k.r.centerX(), k.r.centerY(), k.r.height() * (0.4f + 1.1f * age), p)
                    anim = true
                }
            }
        }
        if (anim || down.any { it }) postInvalidateOnAnimation()
    }

    private fun glow(c: Canvas, r: RectF, col: Int, a: Float) {
        val n = 6; val st = gSize / n
        p.shader = null; p.style = Paint.Style.FILL
        for (j in n downTo 1) {
            p.color = col; p.alpha = (255f * a * 0.11f).toInt()
            val g = j * st
            c.drawRoundRect(r.left - g, r.top - g, r.right + g, r.bottom + g, rad + g, rad + g, p)
        }
    }

    private fun drawKey(c: Canvas, k: Key, pr: Boolean, big: Boolean) {
        var base = perKey["kc_" + k.code] ?: if (k.fn) cFn else cKey
        if (k.code == "SHIFT" && shift) base = cGlow
        if (big) base = shade(base, 1.3f)
        val r = k.r; val dz = dp(4f)
        val py = if (pr && style == 1) dz * 0.75f else 0f
        p.shader = null
        when (style) {
            1 -> { // 3D keycap
                p.style = Paint.Style.FILL; p.color = shade(base, 0.5f)
                c.drawRoundRect(r.left, r.top + dz, r.right, r.bottom + dz, rad, rad, p)
                p.color = Color.WHITE
                p.shader = LinearGradient(0f, r.top + py, 0f, r.bottom + py, shade(base, 1.25f), shade(base, 0.92f), Shader.TileMode.CLAMP)
                c.drawRoundRect(r.left, r.top + py, r.right, r.bottom + py, rad, rad, p)
                p.shader = null; p.style = Paint.Style.STROKE; p.strokeWidth = dp(1f)
                p.color = Color.WHITE; p.alpha = 45
                c.drawRoundRect(r.left + 1f, r.top + py + 1f, r.right - 1f, r.bottom + py - 1f, rad, rad, p)
            }
            2 -> { // glass
                p.style = Paint.Style.FILL; p.color = base; p.alpha = if (pr) 140 else 80
                c.drawRoundRect(r, rad, rad, p)
                p.color = Color.WHITE
                p.shader = LinearGradient(0f, r.top, 0f, r.centerY(), Color.argb(90, 255, 255, 255), Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP)
                c.drawRoundRect(r, rad, rad, p)
                p.shader = null; p.style = Paint.Style.STROKE; p.strokeWidth = dp(1.5f)
                p.color = shade(base, 1.4f); p.alpha = 200
                c.drawRoundRect(r, rad, rad, p)
            }
            else -> { // flat
                p.style = Paint.Style.FILL; p.color = if (pr) shade(base, 0.8f) else base
                c.drawRoundRect(r, rad, rad, p)
            }
        }
        val lab = label(k)
        if (lab.isNotEmpty()) {
            tp.color = cLg; tp.textSize = dp(if (lab.length == 1) 21f else 15f)
            c.drawText(lab, r.centerX(), r.centerY() + tp.textSize * 0.35f + py, tp)
        }
    }

    private fun bubble(c: Canvas, k: Key) {
        val r = k.r; val bw = r.width() * 1.5f; val bh = r.height() * 1.2f
        val cx = r.centerX().coerceIn(bw / 2, width - bw / 2)
        val b = RectF(cx - bw / 2, r.top - bh - dp(4f), cx + bw / 2, r.top - dp(4f))
        val base = perKey["kc_" + k.code] ?: cKey
        val e = dp(5f)
        p.shader = null; p.style = Paint.Style.FILL
        p.color = cGlow; p.alpha = 90
        c.drawRoundRect(b.left - e, b.top - e, b.right + e, b.bottom + e, rad + e, rad + e, p)
        p.color = shade(base, 1.35f)
        c.drawRoundRect(b, rad + dp(4f), rad + dp(4f), p)
        c.drawRect(r.centerX() - r.width() * 0.4f, b.bottom - rad, r.centerX() + r.width() * 0.4f, r.top, p)
        tp.color = cLg; tp.textSize = dp(32f)
        c.drawText(label(k), cx, b.centerY() + tp.textSize * 0.35f, tp)
    }

    // ---------- touch ----------
    private fun hit(x: Float, y: Float): Int {
        val ex = dp(3f); val ey = dp(4f)
        for ((i, k) in keys.withIndex())
            if (x >= k.r.left - ex && x <= k.r.right + ex && y >= k.r.top - ey && y <= k.r.bottom + ey) return i
        return -1
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex
                val idx = hit(e.getX(i), e.getY(i))
                if (idx >= 0) {
                    ptr.put(e.getPointerId(i), idx); down[idx] = true
                    last[idx] = SystemClock.uptimeMillis(); fire(idx)
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                val id = e.getPointerId(e.actionIndex)
                val idx = ptr.get(id, -1)
                if (idx >= 0 && idx < down.size) down[idx] = false
                ptr.delete(id); hd.removeCallbacks(rep)
            }
            MotionEvent.ACTION_CANCEL -> { down.fill(false); ptr.clear(); hd.removeCallbacks(rep) }
        }
        invalidate()
        return true
    }

    private fun fire(idx: Int) {
        val k = keys[idx]
        if (haptic) performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        play(k.fn)
        when (k.code) {
            "SHIFT" -> shift = !shift
            "123" -> { layer = 1; build() }
            "ABC" -> { layer = 0; build() }
            "DEL" -> { send("DEL"); hd.postDelayed(rep, 400) }
            "SPACE" -> send(" ")
            "ENTER" -> send("ENTER")
            else -> { send(if (shift && layer == 0) k.code.uppercase() else k.code); shift = false }
        }
    }

    // ---------- sound (synthesized, no audio files needed) ----------
    private fun gen(pk: Int): ShortArray {
        val sr = 22050; val n = (sr * 0.12).toInt(); val rnd = java.util.Random(7)
        return ShortArray(n) { i ->
            val t = i / sr.toDouble()
            val v = when (pk) {
                1 -> sin(2 * PI * 520 * t) * exp(-t * 55)                       // soft
                2 -> (if (t < 0.006) rnd.nextDouble() * 2 - 1 else 0.0) * 0.9 +  // clicky
                        (if (sin(2 * PI * 2400 * t) > 0) 1.0 else -1.0) * exp(-t * 160) * 0.3
                3 -> sin(2 * PI * (190 * t - 600 * t * t)) * exp(-t * 38)       // thock
                else -> sin(2 * PI * (350 * t + 4000 * t * t)) * exp(-t * 45)   // pop
            }
            (v.coerceIn(-1.0, 1.0) * 26000).toInt().toShort()
        }
    }

    private fun track(pk: Int): AudioTrack? = tracks[pk] ?: try {
        val data = gen(pk)
        val t = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(22050).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(data.size * 2)
            .setTransferMode(AudioTrack.MODE_STATIC).build()
        t.write(data, 0, data.size); tracks[pk] = t; t
    } catch (e: Exception) { null }

    private fun play(fn: Boolean) {
        if (pack == 0) return
        val t = track(pack) ?: return
        try {
            t.stop(); t.reloadStaticData(); t.setVolume(vol)
            t.playbackParams = PlaybackParams().setSpeed(1f)
                .setPitch(if (fn) 0.8f else 0.92f + Random.nextFloat() * 0.16f)
            t.play()
        } catch (e: Exception) { }
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        hd.removeCallbacks(rep)
        tracks.forEach { it?.release() }
        tracks.fill(null)
    }
}
