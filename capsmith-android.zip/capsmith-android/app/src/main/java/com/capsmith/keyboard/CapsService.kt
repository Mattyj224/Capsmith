package com.capsmith.keyboard

import android.inputmethodservice.InputMethodService
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo

class CapsService : InputMethodService() {
    private var view: KbView? = null

    override fun onCreateInputView(): View {
        val v = KbView(this) { code -> onCode(code) }
        view = v
        return v
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        view?.reload()
    }

    override fun onEvaluateFullscreenMode() = false

    private fun onCode(code: String) {
        val ic = currentInputConnection ?: return
        when (code) {
            "DEL" -> sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
            "ENTER" -> {
                val o = currentInputEditorInfo?.imeOptions ?: 0
                val a = o and EditorInfo.IME_MASK_ACTION
                if ((o and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0 ||
                    a == EditorInfo.IME_ACTION_NONE || a == EditorInfo.IME_ACTION_UNSPECIFIED
                ) sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER) else ic.performEditorAction(a)
            }
            else -> ic.commitText(code, 1)
        }
    }
}
