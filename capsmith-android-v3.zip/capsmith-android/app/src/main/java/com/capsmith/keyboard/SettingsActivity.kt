package com.capsmith.keyboard

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.text.InputFilter
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.*

class SettingsActivity : Activity() {
    private lateinit var sp: SharedPreferences
    private lateinit var box: LinearLayout
    private lateinit var kb: KbView
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun changed() = kb.reload()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        sp = getSharedPreferences("cs", MODE_PRIVATE)
        val test = EditText(this).apply {
            hint = "Type on the preview keyboard below"
            showSoftInputOnFocus = false
            minLines = 2
        }
        kb = KbView(this) { code ->
            when (code) {
                "DEL" -> {
                    val t = test.text
                    if (t.isNotEmpty()) t.delete(t.length - 1, t.length)
                }
                "ENTER" -> test.append("\n")
                else -> test.append(code)
            }
        }
        box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(40))
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            fitsSystemWindows = true
            addView(test, LinearLayout.LayoutParams(-1, -2))
            addView(ScrollView(this@SettingsActivity).apply { addView(box) }, LinearLayout.LayoutParams(-1, 0, 1f))
            addView(kb, LinearLayout.LayoutParams(-1, -2))
        }
        setContentView(root)
        ui()
    }

    private fun ui() {
        box.removeAllViews()
        head("Capsmith")
        btn("1. Turn on the keyboard") { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        btn("2. Switch to Capsmith") {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        }

        head("Quick looks")
        val hs = HorizontalScrollView(this)
        val row = LinearLayout(this)
        for ((n, m) in Themes.presets) {
            val b = Button(this)
            b.text = n
            b.isAllCaps = false
            b.setOnClickListener { Themes.applyTheme(sp, m); changed(); ui() }
            row.addView(b)
        }
        hs.addView(row)
        box.addView(hs)

        head("Key style")
        choice("Look", "style", listOf("Flat", "3D keycap", "Glass", "Neon outline"), 1)
        slider("Corner roundness", "radius", 0, 24, 10)
        slider("Key height", "kh", 36, 64, 50)
        slider("Space between keys", "gap", 2, 14, 6)
        color("Key color", "key", D.key)
        color("Function key color", "fn", D.fn)
        color("Legend (letter) color", "legend", D.legend)
        color("Keyboard background", "bg", D.bg)

        head("Single-key colors")
        val one = EditText(this)
        one.hint = "Type one letter or number"
        one.filters = arrayOf(InputFilter.LengthFilter(1))
        box.addView(one)
        btn("Pick a color for that key") {
            val ch = one.text.toString().lowercase()
            if (ch.isNotEmpty()) pick(sp.getInt("kc_$ch", sp.getInt("key", D.key))) {
                sp.edit().putInt("kc_$ch", it).apply(); changed()
            }
        }
        btn("Clear all single-key colors") {
            val e = sp.edit()
            sp.all.keys.filter { it.startsWith("kc_") }.forEach { e.remove(it) }
            e.apply(); changed()
        }

        head("Underglow")
        choice(
            "Effect", "gmode",
            listOf("Off", "Solid", "Breathing", "Rainbow wave", "Reactive (lights where you type)", "Twinkle", "Aurora (two colors)"), 3
        )
        color("Glow color", "glow", D.glow)
        color("Second glow color (Aurora)", "glow2", D.glow2)
        slider("Glow size", "gsize", 0, 30, 12)
        slider("Glow brightness", "gpow", 0, 100, 60)
        slider("Animation speed", "gspeed", 1, 10, 5)

        head("Key press pop-up")
        choice("Pop-up", "popup", listOf("None", "Bubble", "Zoom", "Ripple ring", "Floating letter", "Sparks"), 1)

        head("Sound and feel")
        choice("Key sound", "sound", listOf("Off", "Soft", "Clicky", "Thock", "Pop", "Typewriter", "Marimba (a note per key)"), 2)
        slider("Volume", "vol", 0, 100, 60)
        val sw = Switch(this)
        sw.text = "Vibrate on key press"
        sw.isChecked = sp.getBoolean("haptic", true)
        sw.setOnCheckedChangeListener { _, c -> sp.edit().putBoolean("haptic", c).apply(); changed() }
        box.addView(sw)

        head("My designs")
        val nm = EditText(this)
        nm.hint = "Name this design"
        nm.setSingleLine()
        box.addView(nm)
        btn("Save the current look") {
            var n = nm.text.toString().trim().ifEmpty { "My design" }
            if (Themes.presets.containsKey(n)) n += " 2"
            Themes.save(sp, n)
            ui()
        }
        for ((n, m) in Themes.saved(sp)) {
            val r = LinearLayout(this)
            val use = Button(this)
            use.text = "Use: $n"
            use.isAllCaps = false
            use.setOnClickListener { Themes.applyTheme(sp, m); changed(); ui() }
            val del = Button(this)
            del.text = "Delete"
            del.isAllCaps = false
            del.setOnClickListener { Themes.delete(sp, n); ui() }
            r.addView(use, LinearLayout.LayoutParams(0, -2, 1f))
            r.addView(del)
            box.addView(r)
        }
        label("Tip: tap the ◐ key on the keyboard to cycle through every quick look and your saved designs.")

        head("Reset")
        btn("Reset to the default look") {
            Themes.applyTheme(sp, emptyMap())
            changed()
            ui()
        }
    }

    private fun head(t: String) {
        val v = TextView(this)
        v.text = t
        v.textSize = 18f
        v.setTypeface(null, Typeface.BOLD)
        v.setPadding(0, dp(24), 0, dp(6))
        box.addView(v)
    }

    private fun btn(t: String, f: () -> Unit) {
        val b = Button(this)
        b.text = t
        b.isAllCaps = false
        b.setOnClickListener { f() }
        box.addView(b)
    }

    private fun label(t: String) {
        val v = TextView(this)
        v.text = t
        v.setPadding(0, dp(10), 0, 0)
        box.addView(v)
    }

    private fun color(title: String, key: String, def: Int) {
        val b = Button(this)
        b.isAllCaps = false
        b.text = title
        fun paint() {
            val c = sp.getInt(key, def)
            val g = GradientDrawable()
            g.setColor(c)
            g.cornerRadius = dp(10).toFloat()
            g.setStroke(dp(1), Color.GRAY)
            b.background = g
            b.setTextColor(if (Color.luminance(c) > 0.5f) Color.BLACK else Color.WHITE)
        }
        paint()
        b.setOnClickListener {
            pick(sp.getInt(key, def)) { sp.edit().putInt(key, it).apply(); paint(); changed() }
        }
        box.addView(b)
    }

    private fun pick(start: Int, done: (Int) -> Unit) {
        val hsv = FloatArray(3)
        Color.colorToHSV(start, hsv)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(10), dp(20), 0)
        val sw = View(this)
        col.addView(sw, LinearLayout.LayoutParams(-1, dp(48)))
        fun cur() = Color.HSVToColor(hsv)
        fun upd() = sw.setBackgroundColor(cur())
        fun bar(name: String, max: Int, v: Int, set: (Int) -> Unit) {
            val tv = TextView(this)
            tv.text = name
            col.addView(tv)
            val sb = SeekBar(this)
            sb.max = max
            sb.progress = v
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { set(p); upd() }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
            col.addView(sb)
        }
        bar("Hue", 360, hsv[0].toInt()) { hsv[0] = it.toFloat() }
        bar("Saturation", 100, (hsv[1] * 100).toInt()) { hsv[1] = it / 100f }
        bar("Brightness", 100, (hsv[2] * 100).toInt()) { hsv[2] = it / 100f }
        upd()
        AlertDialog.Builder(this).setView(col)
            .setPositiveButton("Use color") { _, _ -> done(cur()) }
            .setNegativeButton("Cancel", null).show()
    }

    private fun choice(title: String, key: String, opts: List<String>, def: Int) {
        label(title)
        val s = Spinner(this)
        s.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, opts)
        s.setSelection(sp.getInt(key, def))
        s.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (sp.getInt(key, def) != pos) {
                    sp.edit().putInt(key, pos).apply()
                    changed()
                }
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        box.addView(s)
    }

    private fun slider(title: String, key: String, lo: Int, hi: Int, def: Int) {
        label(title)
        val sb = SeekBar(this)
        sb.max = hi - lo
        sb.progress = sp.getInt(key, def) - lo
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                if (u) {
                    sp.edit().putInt(key, p + lo).apply()
                    changed()
                }
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(sb)
    }
}
