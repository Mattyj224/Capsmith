package com.capsmith.keyboard

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.PlaybackParams
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.SparseIntArray
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sin
import kotlin.random.Random

/** Default colors (the "Midnight" look). */
object D {
    val bg = 0xFF10131C.toInt()
    val key = 0xFF2A3042.toInt()
    val fn = 0xFF1B2030.toInt()
    val legend = 0xFFE6EBFF.toInt()
    val glow = 0xFF6F8BFF.toInt()
    val glow2 = 0xFFFF5CC8.toInt()
}

private val FNS = setOf("SHIFT", "DEL", "ENTER", "L0", "L1", "L2", "L3", "PAGE", "THEME")
private val MAJOR = intArrayOf(0, 2, 4, 5, 7, 9, 11)
private val EMOJI = listOf(
    "😀 😂 😊 😍 😎 🤔 😭 😡 🥳 😴 🤯 😇 😜 🙄 😬 🤗 😅 😉 😘 🤩 😢 😱 🤪 😤",
    "👍 👎 👏 🙌 🙏 💪 👀 💖 ❤️ 🧡 💛 💚 💙 💜 🖤 💔 ✌️ 🤞 👌 🤝 👋 🤙 ☝️ ✊",
    "🔥 ✨ 🎉 💯 ⭐ 🌈 ☀️ 🌙 🎮 🎧 🎵 ⌨️ 💻 📱 🚀 💡 🍕 🍔 🍟 ☕ 🍺 🎂 🐶 🐱"
)

/** Long-press extras: digits on the top row, accents, and punctuation variants. */
private val ALT = mapOf(
    "q" to "1", "w" to "2", "e" to "3èéêëēėę", "r" to "4ŕ", "t" to "5þ", "y" to "6ýÿ",
    "u" to "7ùúûüū", "i" to "8ìíîïī", "o" to "9òóôöõøœ", "p" to "0",
    "a" to "àáâäæãåā", "s" to "śšß", "d" to "ð", "l" to "ł", "z" to "žźż", "c" to "çćč", "n" to "ñń",
    "." to "…·", "," to ";", "?" to "¿", "!" to "¡", "-" to "–—", "\$" to "€£¥¢", "'" to "‘’",
    "\"" to "“”«»", "0" to "°", "1" to "¹½", "2" to "²", "3" to "³¾", "&" to "§", "/" to "\\"
)

class KbView(ctx: Context, private val send: (String) -> Unit) : View(ctx) {
    private class Key(val code: String, val label: String, val fn: Boolean, val w: Float, val row: Int) {
        val r = RectF()
    }

    private val sp = ctx.getSharedPreferences("cs", Context.MODE_PRIVATE)
    private val dm = resources.displayMetrics.density
    private fun dp(v: Float) = v * dm
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val pth = Path()
    private val hd = Handler(Looper.getMainLooper())
    private var keys: List<Key> = emptyList()
    private var layer = 0
    private var page = 0
    private var shift = 0              // 0 off, 1 once, 2 caps lock
    private var lastShift = 0L
    private val down = BooleanArray(64)
    private val last = LongArray(64)
    private val ptr = SparseIntArray()
    private var perKey: Map<String, Int> = emptyMap()
    private var toast = ""
    private var toastUntil = 0L

    private var lpActive = false
    private var lpPtr = -1
    private var lpIdx = -1
    private var lpX = 0f

    private var cBg = D.bg
    private var cKey = D.key
    private var cFn = D.fn
    private var cLg = D.legend
    private var cGlow = D.glow
    private var cGlow2 = D.glow2
    private var style = 1
    private var gMode = 3
    private var gSize = 0f
    private var speed = 1f
    private var gPow = 0.6f
    private var popup = 1
    private var pack = 2
    private var vol = 0.6f
    private var rad = 0f
    private var kh = 0f
    private var gx = 0f
    private var gy = 0f
    private var haptic = true

    private val tracks = arrayOfNulls<AudioTrack>(7)
    private val rep = object : Runnable {
        override fun run() {
            send("DEL"); play(0.82f); hd.postDelayed(this, 55)
        }
    }
    private val lpRun = Runnable {
        if (lpIdx in keys.indices && ptr.get(lpPtr, -1) == lpIdx && altsOf(keys[lpIdx]).isNotEmpty()) {
            lpActive = true
            if (haptic) performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            invalidate()
        }
    }

    init {
        reload()
        build()
    }

    fun reload() {
        cBg = sp.getInt("bg", D.bg); cKey = sp.getInt("key", D.key); cFn = sp.getInt("fn", D.fn)
        cLg = sp.getInt("legend", D.legend); cGlow = sp.getInt("glow", D.glow); cGlow2 = sp.getInt("glow2", D.glow2)
        style = sp.getInt("style", 1); gMode = sp.getInt("gmode", 3)
        gSize = dp(sp.getInt("gsize", 12).toFloat()); speed = sp.getInt("gspeed", 5) / 5f
        gPow = sp.getInt("gpow", 60) / 100f
        popup = sp.getInt("popup", 1); pack = sp.getInt("sound", 2)
        vol = sp.getInt("vol", 60) / 100f; rad = dp(sp.getInt("radius", 10).toFloat())
        kh = dp(sp.getInt("kh", 50).toFloat()); gx = dp(sp.getInt("gap", 6).toFloat()); gy = gx + dp(2f)
        haptic = sp.getBoolean("haptic", true)
        perKey = sp.all.filter { it.key.startsWith("kc_") && it.value is Int }.mapValues { it.value as Int }
        place(width.toFloat())
        requestLayout()
        invalidate()
    }

    // ---------- layout ----------
    private fun top() = kh * 1.2f + dp(12f)

    override fun onMeasure(w: Int, hs: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), (top() + 4 * kh + 3 * gy + dp(18f)).toInt())
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) = place(w.toFloat())

    private fun build() {
        val l = ArrayList<Key>()
        fun add(code: String, label: String, fn: Boolean, w: Float, row: Int) {
            l.add(Key(code, label, fn, w, row))
        }
        fun chars(s: String, row: Int) = s.forEach { add(it.toString(), it.toString(), false, 1f, row) }
        when (layer) {
            0 -> {
                chars("qwertyuiop", 0); chars("asdfghjkl", 1)
                add("SHIFT", "⇧", true, 1.5f, 2); chars("zxcvbnm", 2); add("DEL", "⌫", true, 1.5f, 2)
            }
            1 -> {
                chars("1234567890", 0); chars("-/:;()\$&@\"", 1)
                add("L2", "#+=", true, 1.5f, 2); chars(".,?!'", 2); add("DEL", "⌫", true, 1.5f, 2)
            }
            2 -> {
                chars("[]{}#%^*+=", 0); chars("_\\|~<>€£¥•", 1)
                add("L1", "123", true, 1.5f, 2); chars(".,?!'", 2); add("DEL", "⌫", true, 1.5f, 2)
            }
            else -> {
                val e = EMOJI[page].split(" ")
                for (j in 0 until minOf(24, e.size)) add(e[j], e[j], false, 1f, j / 8)
            }
        }
        if (layer == 3) {
            add("L0", "ABC", true, 1.6f, 3); add("PAGE", "${page + 1}/${EMOJI.size}", true, 1.5f, 3)
            add("THEME", "◐", true, 1f, 3); add(" ", "", false, 3.5f, 3)
            add("DEL", "⌫", true, 1.5f, 3); add("ENTER", "⏎", true, 1.6f, 3)
        } else {
            add(if (layer == 0) "L1" else "L0", if (layer == 0) "123" else "ABC", true, 1.5f, 3)
            add("L3", "🙂", true, 1.1f, 3); add("THEME", "◐", true, 1.1f, 3)
            add(",", ",", false, 1f, 3); add(" ", "", false, 3.3f, 3); add(".", ".", false, 1f, 3)
            add("ENTER", "⏎", true, 1.5f, 3)
        }
        keys = l
        down.fill(false); last.fill(0L); ptr.clear(); lpActive = false
        place(width.toFloat())
        invalidate()
    }

    private fun place(width: Float) {
        if (width <= 0f) return
        val pad = dp(6f)
        val avail = width - 2 * pad
        val unit0 = (avail - 9 * gx) / 10f
        for (row in 0..3) {
            val rk = keys.filter { it.row == row }
            if (rk.isEmpty()) continue
            val n = rk.size
            val sum = rk.sumOf { it.w.toDouble() }.toFloat()
            val unit = if (row == 3 || layer == 3) (avail - (n - 1) * gx) / sum else unit0
            var x = (width - (sum * unit + (n - 1) * gx)) / 2f
            val y = top() + row * (kh + gy)
            for (k in rk) {
                val kw = k.w * unit
                k.r.set(x, y, x + kw, y + kh)
                x += kw + gx
            }
        }
    }

    // ---------- helpers ----------
    private fun shade(c: Int, f: Float): Int {
        val h = FloatArray(3)
        Color.colorToHSV(c, h)
        h[2] = (h[2] * f + (if (f > 1f) (f - 1f) * 0.2f else 0f)).coerceIn(0f, 1f)
        return Color.HSVToColor(Color.alpha(c), h)
    }

    private fun mix(a: Int, b: Int, f: Float): Int = Color.rgb(
        (Color.red(a) + (Color.red(b) - Color.red(a)) * f).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * f).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * f).toInt()
    )

    private fun label(k: Key): String = when {
        k.code == "SHIFT" -> if (shift == 2) "⇪" else "⇧"
        shift > 0 && layer == 0 && k.code.length == 1 && k.code[0].isLetter() -> k.label.uppercase()
        else -> k.label
    }

    private fun altsOf(k: Key): String {
        val a = ALT[k.code] ?: return ""
        return if (shift > 0 && layer == 0) a.map { it.uppercaseChar() }.joinToString("") else a
    }

    private fun strip(n: Int, k: Key): RectF {
        val w = dp(40f) * n
        val l = (k.r.centerX() - dp(20f)).coerceIn(0f, max(0f, width - w))
        return RectF(l, k.r.top - kh - dp(8f), l + w, k.r.top - dp(8f))
    }

    private fun selIdx(k: Key, n: Int): Int =
        ((lpX - strip(n, k).left) / dp(40f)).toInt().coerceIn(0, n - 1)

    // ---------- drawing ----------
    override fun onDraw(c: Canvas) {
        val now = SystemClock.uptimeMillis()
        val t = now / 1000f
        var anim = false
        c.drawColor(cBg)

        if (gMode > 0 && gSize > 0f) for ((i, k) in keys.withIndex()) {
            var a = 1f
            var col = cGlow
            when (gMode) {
                2 -> { a = 0.55f + 0.45f * sin(t * 2.2f * speed); anim = true }
                3 -> {
                    val hue = (t * 45f * speed + k.r.centerX() / width * 360f + k.row * 25f) % 360f
                    col = Color.HSVToColor(floatArrayOf(hue, 0.85f, 1f)); anim = true
                }
                4 -> { a = max(0.12f, 1f - (now - last[i]) / 1200f); if (a > 0.12f) anim = true }
                5 -> {
                    val ph = sin(t * 3f * speed + i * 2.4f)
                    a = (ph * ph * ph * ph).coerceIn(0.05f, 1f); anim = true
                }
                6 -> {
                    val m = 0.5f + 0.5f * sin(t * 0.9f * speed + k.r.centerX() / width * 6.28f + k.row * 0.7f)
                    col = mix(cGlow, cGlow2, m); anim = true
                }
            }
            glow(c, k.r, col, a)
        }

        for ((i, k) in keys.withIndex()) drawKey(c, k, down[i], false)

        for ((i, k) in keys.withIndex()) {
            val age = if (last[i] > 0L) (now - last[i]) / 500f else 9f
            val tx = k.code !in FNS
            if (down[i] && tx) {
                when (popup) {
                    1 -> bubble(c, k)
                    2 -> {
                        c.save(); c.scale(1.3f, 1.3f, k.r.centerX(), k.r.bottom)
                        drawKey(c, k, false, true); c.restore()
                    }
                }
            }
            if (age in 0f..1f) {
                when (popup) {
                    3 -> {
                        p.shader = null; p.style = Paint.Style.STROKE; p.strokeWidth = dp(3f)
                        p.color = cGlow; p.alpha = (255 * (1f - age)).toInt()
                        c.drawCircle(k.r.centerX(), k.r.centerY(), k.r.height() * (0.4f + 1.1f * age), p)
                        anim = true
                    }
                    4 -> if (tx) {
                        tp.color = cGlow; tp.alpha = (255 * (1f - age)).toInt(); tp.textSize = dp(24f)
                        c.drawText(label(k), k.r.centerX(), k.r.top - age * dp(46f), tp)
                        anim = true
                    }
                    5 -> {
                        p.shader = null; p.style = Paint.Style.FILL
                        p.color = cGlow; p.alpha = (255 * (1f - age)).toInt()
                        for (s in 0 until 8) {
                            val ang = s * 0.785f + i
                            val d = dp(14f) + age * dp(34f)
                            c.drawCircle(
                                k.r.centerX() + cos(ang) * d, k.r.centerY() + sin(ang) * d,
                                dp(3f) * (1f - age) + 1f, p
                            )
                        }
                        anim = true
                    }
                }
            }
        }

        if (lpActive && lpIdx in keys.indices) {
            val k = keys[lpIdx]
            val a = altsOf(k)
            if (a.isNotEmpty()) {
                val s = strip(a.length, k)
                val cw = dp(40f)
                val sel = selIdx(k, a.length)
                p.shader = null; p.style = Paint.Style.FILL; p.color = shade(cKey, 1.3f)
                c.drawRoundRect(s, rad + dp(4f), rad + dp(4f), p)
                for (j in a.indices) {
                    if (j == sel) {
                        p.color = cGlow
                        c.drawRoundRect(
                            s.left + j * cw + dp(3f), s.top + dp(4f),
                            s.left + (j + 1) * cw - dp(3f), s.bottom - dp(4f), rad, rad, p
                        )
                    }
                    tp.color = if (j == sel) Color.WHITE else cLg
                    tp.textSize = dp(22f)
                    c.drawText(a[j].toString(), s.left + j * cw + cw / 2, s.centerY() + tp.textSize * 0.35f, tp)
                }
            }
        }

        if (now < toastUntil) {
            tp.color = cLg; tp.textSize = dp(15f)
            c.drawText(toast, width / 2f, dp(20f), tp)
            anim = true
        }
        if (anim || lpActive || down.any { it }) postInvalidateOnAnimation()
    }

    private fun glow(c: Canvas, r: RectF, col: Int, a: Float) {
        val n = 10
        val st = gSize / n
        val oy = gSize * 0.18f
        p.shader = null; p.style = Paint.Style.FILL; p.color = col
        for (j in n downTo 1) {
            p.alpha = (255f * a * gPow * 0.22f * (1f - (j - 1f) / n)).coerceIn(0f, 255f).toInt()
            val g = j * st
            c.drawRoundRect(r.left - g, r.top - g + oy, r.right + g, r.bottom + g + oy, rad + g, rad + g, p)
        }
    }

    private fun drawKey(c: Canvas, k: Key, pr: Boolean, big: Boolean) {
        var base = perKey["kc_" + k.code] ?: if (k.fn) cFn else cKey
        if (k.code == "SHIFT" && shift > 0) base = if (shift == 2) mix(cGlow, Color.WHITE, 0.25f) else cGlow
        if (big) base = shade(base, 1.3f)
        val r = k.r
        val dz = dp(5f)
        val py = if (pr && style == 1) dz * 0.8f else 0f
        var ly = 0f
        p.shader = null
        when (style) {
            1 -> { // 3D keycap: shadow, body, dished top face
                p.style = Paint.Style.FILL; p.color = shade(base, 0.42f)
                c.drawRoundRect(r.left, r.top + dz, r.right, r.bottom + dz, rad, rad, p)
                p.color = Color.WHITE
                p.shader = LinearGradient(
                    0f, r.top, 0f, r.bottom + py, shade(base, 0.95f), shade(base, 0.7f), Shader.TileMode.CLAMP
                )
                c.drawRoundRect(r.left, r.top + py, r.right, r.bottom + py, rad, rad, p)
                val ix = dp(3f)
                val fr = RectF(r.left + ix, r.top + py + dp(2f), r.right - ix, r.bottom + py - dp(5f))
                p.shader = LinearGradient(
                    0f, fr.top, 0f, fr.bottom, shade(base, 1.3f), shade(base, 1.04f), Shader.TileMode.CLAMP
                )
                c.drawRoundRect(fr, rad * 0.8f, rad * 0.8f, p)
                p.shader = null; p.style = Paint.Style.STROKE; p.strokeWidth = dp(1f)
                p.color = Color.WHITE; p.alpha = 50
                c.drawRoundRect(fr, rad * 0.8f, rad * 0.8f, p)
                ly = py - dp(1.5f)
            }
            2 -> { // glass
                p.style = Paint.Style.FILL; p.color = base; p.alpha = if (pr) 140 else 80
                c.drawRoundRect(r, rad, rad, p)
                p.color = Color.WHITE
                p.shader = LinearGradient(
                    0f, r.top, 0f, r.centerY(), Color.argb(90, 255, 255, 255), Color.argb(0, 255, 255, 255),
                    Shader.TileMode.CLAMP
                )
                c.drawRoundRect(r, rad, rad, p)
                p.shader = null; p.style = Paint.Style.STROKE; p.strokeWidth = dp(1.5f)
                p.color = shade(base, 1.4f); p.alpha = 200
                c.drawRoundRect(r, rad, rad, p)
            }
            3 -> { // neon outline
                val nc = perKey["kc_" + k.code] ?: cGlow
                p.style = Paint.Style.FILL; p.color = if (pr) nc else shade(cBg, 1.5f)
                p.alpha = if (pr) 110 else 255
                c.drawRoundRect(r, rad, rad, p)
                p.style = Paint.Style.STROKE; p.color = nc
                p.strokeWidth = dp(7f); p.alpha = 30; c.drawRoundRect(r, rad, rad, p)
                p.strokeWidth = dp(4f); p.alpha = 60; c.drawRoundRect(r, rad, rad, p)
                p.strokeWidth = dp(1.8f); p.alpha = 255; c.drawRoundRect(r, rad, rad, p)
            }
            else -> { // flat
                p.style = Paint.Style.FILL; p.color = if (pr) shade(base, 0.8f) else base
                c.drawRoundRect(r, rad, rad, p)
            }
        }
        val lab = label(k)
        if (lab.isNotEmpty()) {
            tp.color = cLg; tp.textSize = dp(if (lab.length <= 2) 21f else 15f)
            c.drawText(lab, r.centerX(), r.centerY() + tp.textSize * 0.35f + ly, tp)
        }
    }

    private fun bubble(c: Canvas, k: Key) {
        val r = k.r
        val bw = r.width() * 1.55f
        val bh = kh * 1.1f
        val cx = r.centerX().coerceIn(bw / 2, width - bw / 2)
        val bl = cx - bw / 2
        val br = cx + bw / 2
        val bb = r.top - dp(6f)
        val bt = bb - bh
        val rr = rad + dp(5f)
        val nk = r.top + dp(3f)
        pth.reset()
        pth.moveTo(bl + rr, bt); pth.lineTo(br - rr, bt); pth.quadTo(br, bt, br, bt + rr)
        pth.lineTo(br, bb); pth.quadTo(br, bb + dp(10f), r.right, nk)
        pth.lineTo(r.right, r.bottom); pth.lineTo(r.left, r.bottom); pth.lineTo(r.left, nk)
        pth.quadTo(bl, bb + dp(10f), bl, bb); pth.lineTo(bl, bt + rr); pth.quadTo(bl, bt, bl + rr, bt)
        pth.close()
        val base = perKey["kc_" + k.code] ?: cKey
        p.shader = null
        p.style = Paint.Style.STROKE; p.strokeWidth = dp(9f); p.color = cGlow; p.alpha = 55; c.drawPath(pth, p)
        p.style = Paint.Style.FILL; p.color = shade(base, 1.35f); c.drawPath(pth, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = dp(1.5f); p.color = cGlow; p.alpha = 255; c.drawPath(pth, p)
        tp.color = cLg; tp.textSize = dp(32f)
        c.drawText(label(k), cx, (bt + bb) / 2 + tp.textSize * 0.35f, tp)
    }

    // ---------- touch ----------
    private fun hit(x: Float, y: Float): Int {
        val ex = gx / 2
        val ey = gy / 2
        for ((i, k) in keys.withIndex())
            if (x >= k.r.left - ex && x <= k.r.right + ex && y >= k.r.top - ey && y <= k.r.bottom + ey) return i
        return -1
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex
                val idx = hit(e.getX(i), e.getY(i))
                if (idx >= 0) {
                    val id = e.getPointerId(i)
                    ptr.put(id, idx); down[idx] = true; last[idx] = SystemClock.uptimeMillis()
                    press(idx)
                    val k = keys.getOrNull(idx)
                    if (k != null && ptr.get(id, -1) == idx && altsOf(k).isNotEmpty()) {
                        lpPtr = id; lpIdx = idx; lpX = e.getX(i)
                        hd.removeCallbacks(lpRun)
                        hd.postDelayed(lpRun, 350)
                    }
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (lpActive) for (i in 0 until e.pointerCount) if (e.getPointerId(i) == lpPtr) lpX = e.getX(i)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                val id = e.getPointerId(e.actionIndex)
                val idx = ptr.get(id, -1)
                hd.removeCallbacks(rep)
                if (idx >= 0) {
                    if (idx < down.size) down[idx] = false
                    val k = keys.getOrNull(idx)
                    if (k != null && id == lpPtr && lpActive) {
                        val a = altsOf(k)
                        if (a.isNotEmpty()) commit(a[selIdx(k, a.length)].toString())
                    } else if (k != null && k.code !in FNS) {
                        commit(k.code)
                    }
                }
                if (id == lpPtr) {
                    lpActive = false; lpPtr = -1; hd.removeCallbacks(lpRun)
                }
                ptr.delete(id)
            }
            MotionEvent.ACTION_CANCEL -> {
                down.fill(false); ptr.clear(); hd.removeCallbacks(rep); hd.removeCallbacks(lpRun)
                lpActive = false; lpPtr = -1
            }
        }
        invalidate()
        return true
    }

    private fun commit(t: String) {
        val up = shift > 0 && layer == 0 && t.length == 1 && t[0].isLetter()
        send(if (up) t[0].uppercaseChar().toString() else t)
        if (shift == 1) shift = 0
    }

    private fun pitchFor(k: Key): Float = when {
        pack == 6 -> 2f.pow(MAJOR[((k.r.centerX() / width * 7).toInt().coerceIn(0, 6) + k.row * 2) % 7] / 12f)
        k.code == " " -> 0.7f
        k.fn -> 0.82f
        else -> 0.92f + Random.nextFloat() * 0.16f
    }

    private fun press(idx: Int) {
        val k = keys[idx]
        if (haptic) performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        play(pitchFor(k))
        when (k.code) {
            "SHIFT" -> {
                val n = SystemClock.uptimeMillis()
                shift = when {
                    shift == 2 -> 0
                    shift == 1 && n - lastShift < 350 -> 2
                    shift == 1 -> 0
                    else -> 1
                }
                lastShift = n
            }
            "L0" -> { layer = 0; build() }
            "L1" -> { layer = 1; build() }
            "L2" -> { layer = 2; build() }
            "L3" -> { layer = 3; build() }
            "PAGE" -> { page = (page + 1) % EMOJI.size; build() }
            "THEME" -> nextTheme()
            "DEL" -> { send("DEL"); hd.postDelayed(rep, 400) }
            "ENTER" -> send("ENTER")
        }
    }

    private fun nextTheme() {
        val names = Themes.names(sp)
        if (names.isEmpty()) return
        val i = (sp.getInt("tidx", -1) + 1) % names.size
        Themes.applyTheme(sp, Themes.get(sp, names[i]) ?: emptyMap())
        sp.edit().putInt("tidx", i).apply()
        reload()
        toast = names[i]
        toastUntil = SystemClock.uptimeMillis() + 1300
    }

    // ---------- sound (synthesized, no audio files needed) ----------
    private fun gen(pk: Int): ShortArray {
        val sr = 22050
        val n = (sr * (if (pk == 6) 0.35 else 0.14)).toInt()
        val rnd = java.util.Random(7)
        return ShortArray(n) { i ->
            val t = i / sr.toDouble()
            val nz = rnd.nextDouble() * 2 - 1
            val v: Double = when (pk) {
                1 -> sin(2 * PI * 520 * t) * exp(-t * 55)                                    // soft
                2 -> (if (t < 0.006) nz * 0.9 else 0.0) +                                     // clicky
                        (if (sin(2 * PI * 2400 * t) > 0) 1.0 else -1.0) * exp(-t * 160) * 0.3
                3 -> sin(2 * PI * (190 * t - 600 * t * t)) * exp(-t * 38) +                   // thock
                        (if (t < 0.004) nz * 0.4 else 0.0)
                4 -> sin(2 * PI * (350 * t + 4000 * t * t)) * exp(-t * 45)                    // pop
                5 -> nz * exp(-t * 220) * 0.8 + sin(2 * PI * 120 * t) * exp(-t * 60) * 0.6 +   // typewriter
                        sin(2 * PI * 3100 * t) * exp(-t * 90) * 0.25
                else -> sin(2 * PI * 440 * t) * exp(-t * 16) +                                // marimba
                        0.35 * sin(2 * PI * 1320 * t) * exp(-t * 40) + 0.15 * sin(2 * PI * 2200 * t) * exp(-t * 70)
            }
            (v.coerceIn(-1.0, 1.0) * 26000).toInt().toShort()
        }
    }

    private fun track(pk: Int): AudioTrack? = tracks[pk] ?: try {
        val data = gen(pk)
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            )
            .setAudioFormat(
                AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(22050).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
            )
            .setBufferSizeInBytes(data.size * 2)
            .setTransferMode(AudioTrack.MODE_STATIC).build()
        t.write(data, 0, data.size)
        tracks[pk] = t
        t
    } catch (e: Exception) {
        null
    }

    private fun play(pitch: Float) {
        if (pack == 0) return
        val t = track(pack) ?: return
        try {
            t.stop(); t.reloadStaticData(); t.setVolume(vol)
            t.playbackParams = PlaybackParams().setSpeed(1f).setPitch(pitch.coerceIn(0.5f, 2f))
            t.play()
        } catch (e: Exception) {
        }
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        hd.removeCallbacks(rep); hd.removeCallbacks(lpRun)
        tracks.forEach { it?.release() }
        tracks.fill(null)
    }
}
